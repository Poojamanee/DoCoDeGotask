import { describe, expect, it } from 'vitest'
import { type Balance, call, createBill, createHome, type Share } from './helpers'

function pay(billId: string, shareId: string, key: string) {
  return call<Share | { error: string }>('POST', `/api/bills/${billId}/shares/${shareId}/pay`, {
    headers: { 'Idempotency-Key': key },
  })
}

describe('extra: input and errors', () => {
  it('answers errors as { error } JSON', async () => {
    const { homeId } = await createHome([])
    const bill = await createBill(homeId, 1000)
    expect(bill.status).toBe(422)
    expect(bill.body).toEqual({ error: expect.any(String) })
  })

  it('rejects blank names and bodies that are not JSON objects', async () => {
    expect((await call('POST', '/api/homes', { body: { name: '   ' } })).status).toBe(422)
    expect((await call('POST', '/api/homes', { body: {} })).status).toBe(422)
    expect((await call('POST', '/api/homes', { body: [1] })).status).toBe(422)
    const raw = await call('POST', '/api/homes', { body: 'not an object' })
    expect(raw.status).toBe(422)
  })

  it('rejects Infinity-like and huge amounts', async () => {
    const { homeId } = await createHome(['Asha'])
    for (const totalCents of [Number.MAX_SAFE_INTEGER + 1, 1e300]) {
      expect((await createBill(homeId, totalCents)).status).toBe(422)
    }
  })

  it('does not leave a bill behind when the home has no members', async () => {
    const { homeId } = await createHome([])
    await createBill(homeId, 1000)
    const bills = await call<{ bills: unknown[] }>('GET', `/api/homes/${homeId}/bills`)
    expect(bills.body.bills).toEqual([])
  })

  it('a share of another bill is 404', async () => {
    const { homeId } = await createHome(['Asha'])
    const a = await createBill(homeId, 100)
    const b = await createBill(homeId, 100)
    const shareOfA = a.body.shares[0]
    if (!shareOfA) throw new Error('no share')
    expect((await pay(b.body.id, shareOfA.id, 'k')).status).toBe(404)
  })
})

describe('extra: splitting', () => {
  it('shares always add up, for many totals and member counts', async () => {
    for (const count of [1, 2, 3, 7]) {
      const { homeId } = await createHome(Array.from({ length: count }, (_, i) => `M${i}`))
      for (const total of [1, 2, 99, 1000, 123457]) {
        const bill = await createBill(homeId, total)
        const amounts = bill.body.shares.map((s) => s.amountCents)
        expect(amounts.reduce((a, b) => a + b, 0)).toBe(total)
        expect(Math.max(...amounts) - Math.min(...amounts)).toBeLessThanOrEqual(1)
        expect([...amounts].sort((a, b) => b - a)).toEqual(amounts) // extra cents go first
      }
    }
  })

  it('gives zero cents to members when the total is smaller than the member count', async () => {
    const { homeId } = await createHome(['A', 'B', 'C'])
    const bill = await createBill(homeId, 2)
    expect(bill.body.shares.map((s) => s.amountCents)).toEqual([1, 1, 0])
  })
})

describe('extra: concurrency', () => {
  it('only one of many parallel payments with different keys succeeds', async () => {
    const { homeId } = await createHome(['Asha', 'Ben'])
    const bill = await createBill(homeId, 1000)
    const share = bill.body.shares[0]
    if (!share) throw new Error('no share')

    const results = await Promise.all(
      Array.from({ length: 10 }, (_, i) => pay(bill.body.id, share.id, `key-${i}`)),
    )
    const statuses = results.map((r) => r.status).sort()
    expect(statuses.filter((s) => s === 200)).toHaveLength(1)
    expect(statuses.filter((s) => s === 409)).toHaveLength(9)

    const balances = await call<{ balances: Balance[] }>('GET', `/api/homes/${homeId}/balances`)
    expect(balances.body.balances.map((b) => b.outstandingCents)).toEqual([0, 500])
  })

  it('parallel payments with the same key all answer 200 with one paidAt', async () => {
    const { homeId } = await createHome(['Asha'])
    const bill = await createBill(homeId, 1000)
    const share = bill.body.shares[0]
    if (!share) throw new Error('no share')

    const results = await Promise.all(
      Array.from({ length: 6 }, () => pay(bill.body.id, share.id, 'same-key')),
    )
    expect(results.every((r) => r.status === 200)).toBe(true)
    const paidAts = new Set(results.map((r) => (r.body as Share).paidAt))
    expect(paidAts.size).toBe(1)
  })

  it('members added in parallel still get consistent, complete shares', async () => {
    const { homeId } = await createHome(['Asha'])
    await Promise.all(
      ['B', 'C', 'D'].map((name) =>
        call('POST', `/api/homes/${homeId}/members`, { body: { name } }),
      ),
    )
    const bill = await createBill(homeId, 1000)
    expect(bill.body.shares).toHaveLength(4)
    expect(bill.body.shares.reduce((a, s) => a + s.amountCents, 0)).toBe(1000)
  })
})
