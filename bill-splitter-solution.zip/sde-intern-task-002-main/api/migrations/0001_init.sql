-- Money is always whole cents (INTEGER). Every constraint is named so a failure
-- message tells you which rule was broken.

CREATE TABLE homes (
  id         TEXT NOT NULL,
  name       TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  CONSTRAINT homes_pk PRIMARY KEY (id),
  -- stops empty or whitespace-only home names
  CONSTRAINT homes_name_not_blank CHECK (length(trim(name)) > 0)
);

CREATE TABLE members (
  -- seq is the order members were added. Part 2 relies on it (who gets the extra cents).
  -- AUTOINCREMENT means a number is never reused, so the order cannot change.
  seq        INTEGER PRIMARY KEY AUTOINCREMENT,
  id         TEXT NOT NULL,
  home_id    TEXT NOT NULL,
  name       TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  CONSTRAINT members_id_unique UNIQUE (id),
  -- stops a member that belongs to a home that does not exist
  CONSTRAINT members_home_fk FOREIGN KEY (home_id) REFERENCES homes (id),
  CONSTRAINT members_name_not_blank CHECK (length(trim(name)) > 0)
);
CREATE INDEX members_home_idx ON members (home_id, seq);

CREATE TABLE bills (
  seq         INTEGER PRIMARY KEY AUTOINCREMENT,
  id          TEXT NOT NULL,
  home_id     TEXT NOT NULL,
  title       TEXT NOT NULL,
  total_cents INTEGER NOT NULL,
  created_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  CONSTRAINT bills_id_unique UNIQUE (id),
  CONSTRAINT bills_home_fk FOREIGN KEY (home_id) REFERENCES homes (id),
  CONSTRAINT bills_title_not_blank CHECK (length(trim(title)) > 0),
  -- stops zero, negative, decimal (REAL) and text amounts, even if the API check is bypassed
  CONSTRAINT bills_total_positive_integer CHECK (typeof(total_cents) = 'integer' AND total_cents > 0)
);
CREATE INDEX bills_home_idx ON bills (home_id, seq);

CREATE TABLE shares (
  id              TEXT NOT NULL,
  bill_id         TEXT NOT NULL,
  member_id       TEXT NOT NULL,
  amount_cents    INTEGER NOT NULL,
  paid_at         TEXT,
  -- the Idempotency-Key that paid this share; used to recognise a repeated request
  idempotency_key TEXT,
  CONSTRAINT shares_pk PRIMARY KEY (id),
  CONSTRAINT shares_bill_fk FOREIGN KEY (bill_id) REFERENCES bills (id),
  CONSTRAINT shares_member_fk FOREIGN KEY (member_id) REFERENCES members (id),
  -- stops a member getting two shares of the same bill
  CONSTRAINT shares_one_per_member UNIQUE (bill_id, member_id),
  CONSTRAINT shares_amount_valid CHECK (typeof(amount_cents) = 'integer' AND amount_cents >= 0),
  -- a share is either unpaid (no time, no key) or paid (time and key); never half of each
  CONSTRAINT shares_paid_consistent CHECK ((paid_at IS NULL) = (idempotency_key IS NULL))
);
CREATE INDEX shares_member_idx ON shares (member_id);
