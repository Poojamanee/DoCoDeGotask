export type Result<T> = { ok: true; value: T } | { ok: false; error: string }

const MAX_TEXT = 200
export const MAX_KEY = 255

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

export function text(value: unknown, field: string): Result<string> {
  if (typeof value !== 'string') return { ok: false, error: `${field} must be a string` }
  const trimmed = value.trim()
  if (trimmed.length === 0) return { ok: false, error: `${field} must not be empty` }
  if (trimmed.length > MAX_TEXT) {
    return { ok: false, error: `${field} must be at most ${MAX_TEXT} characters` }
  }
  return { ok: true, value: trimmed }
}

/** A positive whole number of cents. Rejects 0, negatives, decimals, strings, null, NaN, Infinity. */
export function positiveCents(value: unknown, field: string): Result<number> {
  if (typeof value !== 'number' || !Number.isSafeInteger(value) || value <= 0) {
    return { ok: false, error: `${field} must be a positive whole number of cents` }
  }
  return { ok: true, value }
}

export function parseName(body: unknown): Result<{ name: string }> {
  if (!isRecord(body)) return { ok: false, error: 'body must be a JSON object' }
  const name = text(body.name, 'name')
  return name.ok ? { ok: true, value: { name: name.value } } : name
}

export function parseBill(body: unknown): Result<{ title: string; totalCents: number }> {
  if (!isRecord(body)) return { ok: false, error: 'body must be a JSON object' }
  const title = text(body.title, 'title')
  if (!title.ok) return title
  const total = positiveCents(body.totalCents, 'totalCents')
  if (!total.ok) return total
  return { ok: true, value: { title: title.value, totalCents: total.value } }
}

export function parseIdempotencyKey(header: string | undefined): Result<string> {
  const key = header?.trim()
  if (!key) return { ok: false, error: 'Idempotency-Key header is required' }
  if (key.length > MAX_KEY) return { ok: false, error: 'Idempotency-Key is too long' }
  return { ok: true, value: key }
}
