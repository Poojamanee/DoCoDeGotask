import { Hono } from 'hono'
import { parseBill, parseIdempotencyKey, parseName } from './validation'

type AppEnv = { Bindings: Env }

type HomeRow = { id: string; name: string }
type MemberRow = { id: string; home_id: string; name: string }
type BillRow = { id: string; home_id: string; title: string; total_cents: number }
type ShareRow = {
  id: string
  bill_id: string
  member_id: string
  member_name: string
  amount_cents: number
  paid_at: string | null
}
type PaidShareRow = { id: string; member_id: string; amount_cents: number; paid_at: string }

const app = new Hono<AppEnv>()

// Every error leaves the API as { "error": "message" }.
app.notFound((c) => c.json({ error: 'Not found' }, 404))
app.onError((err, c) => {
  console.error(err)
  return c.json({ error: 'Internal server error' }, 500)
})

app.get('/api/health', (c) => c.json({ status: 'ok' }))

/** Reads the JSON body. A body that is not valid JSON gives undefined, which validation rejects. */
async function readJson(req: Request): Promise<unknown> {
  try {
    return await req.json()
  } catch {
    return undefined
  }
}

function newId(): string {
  return crypto.randomUUID()
}

function homeExists(db: D1Database, homeId: string): Promise<HomeRow | null> {
  return db.prepare('SELECT id, name FROM homes WHERE id = ?').bind(homeId).first<HomeRow>()
}

// ---------- Part 1: homes and members ----------

app.post('/api/homes', async (c) => {
  const parsed = parseName(await readJson(c.req.raw))
  if (!parsed.ok) return c.json({ error: parsed.error }, 422)

  const id = newId()
  await c.env.DB.prepare('INSERT INTO homes (id, name) VALUES (?, ?)')
    .bind(id, parsed.value.name)
    .run()
  return c.json({ id, name: parsed.value.name }, 201)
})

app.get('/api/homes/:homeId', async (c) => {
  const home = await homeExists(c.env.DB, c.req.param('homeId'))
  if (!home) return c.json({ error: 'Home not found' }, 404)

  const { results } = await c.env.DB.prepare(
    'SELECT id, home_id, name FROM members WHERE home_id = ? ORDER BY seq',
  )
    .bind(home.id)
    .all<MemberRow>()
  return c.json({
    id: home.id,
    name: home.name,
    members: results.map((m) => ({ id: m.id, homeId: m.home_id, name: m.name })),
  })
})

app.post('/api/homes/:homeId/members', async (c) => {
  const homeId = c.req.param('homeId')
  if (!(await homeExists(c.env.DB, homeId))) return c.json({ error: 'Home not found' }, 404)

  const parsed = parseName(await readJson(c.req.raw))
  if (!parsed.ok) return c.json({ error: parsed.error }, 422)

  const id = newId()
  await c.env.DB.prepare('INSERT INTO members (id, home_id, name) VALUES (?, ?, ?)')
    .bind(id, homeId, parsed.value.name)
    .run()
  return c.json({ id, homeId, name: parsed.value.name }, 201)
})

// ---------- Part 2: bills ----------

function toShare(row: ShareRow) {
  return {
    id: row.id,
    memberId: row.member_id,
    memberName: row.member_name,
    amountCents: row.amount_cents,
    paidAt: row.paid_at,
  }
}

app.post('/api/homes/:homeId/bills', async (c) => {
  const db = c.env.DB
  const homeId = c.req.param('homeId')
  if (!(await homeExists(db, homeId))) return c.json({ error: 'Home not found' }, 404)

  const parsed = parseBill(await readJson(c.req.raw))
  if (!parsed.ok) return c.json({ error: parsed.error }, 422)
  const { title, totalCents } = parsed.value

  const billId = newId()
  // One batch = one transaction. The members are read inside it, so a member added by another
  // request cannot slip in between "count the members" and "write the shares".
  //  1. insert the bill only if the home has at least one member
  //  2. insert one share per member: total / n, plus 1 cent for the first (total % n) members
  const [billInsert] = await db.batch([
    db
      .prepare(
        `INSERT INTO bills (id, home_id, title, total_cents)
         SELECT ?1, ?2, ?3, ?4
         WHERE EXISTS (SELECT 1 FROM members WHERE home_id = ?2)`,
      )
      .bind(billId, homeId, title, totalCents),
    db
      .prepare(
        `INSERT INTO shares (id, bill_id, member_id, amount_cents)
         SELECT lower(hex(randomblob(16))), ?1, m.id,
                CAST(?2 AS INTEGER) / m.n + CASE WHEN m.rn <= CAST(?2 AS INTEGER) % m.n THEN 1 ELSE 0 END
         FROM (
           SELECT id,
                  ROW_NUMBER() OVER (ORDER BY seq) AS rn,
                  COUNT(*) OVER () AS n
           FROM members WHERE home_id = ?3
         ) AS m
         WHERE EXISTS (SELECT 1 FROM bills WHERE id = ?1)`,
      )
      .bind(billId, totalCents, homeId),
  ])
  if (!billInsert || billInsert.meta.changes === 0) {
    return c.json({ error: 'Home has no members to split the bill between' }, 422)
  }

  const { results } = await db
    .prepare(
      `SELECT s.id, s.bill_id, s.member_id, m.name AS member_name, s.amount_cents, s.paid_at
       FROM shares s JOIN members m ON m.id = s.member_id
       WHERE s.bill_id = ? ORDER BY m.seq`,
    )
    .bind(billId)
    .all<ShareRow>()
  return c.json({ id: billId, homeId, title, totalCents, shares: results.map(toShare) }, 201)
})

app.get('/api/homes/:homeId/bills', async (c) => {
  const db = c.env.DB
  const homeId = c.req.param('homeId')
  if (!(await homeExists(db, homeId))) return c.json({ error: 'Home not found' }, 404)

  const [bills, shares] = await db.batch<BillRow | ShareRow>([
    db
      .prepare(
        'SELECT id, home_id, title, total_cents FROM bills WHERE home_id = ? ORDER BY seq DESC',
      )
      .bind(homeId),
    db
      .prepare(
        `SELECT s.id, s.bill_id, s.member_id, m.name AS member_name, s.amount_cents, s.paid_at
         FROM shares s
         JOIN bills b ON b.id = s.bill_id
         JOIN members m ON m.id = s.member_id
         WHERE b.home_id = ? ORDER BY m.seq`,
      )
      .bind(homeId),
  ])

  const sharesByBill = new Map<string, ShareRow[]>()
  for (const row of (shares?.results ?? []) as ShareRow[]) {
    const list = sharesByBill.get(row.bill_id) ?? []
    list.push(row)
    sharesByBill.set(row.bill_id, list)
  }
  return c.json({
    bills: ((bills?.results ?? []) as BillRow[]).map((b) => ({
      id: b.id,
      homeId: b.home_id,
      title: b.title,
      totalCents: b.total_cents,
      shares: (sharesByBill.get(b.id) ?? []).map(toShare),
    })),
  })
})

// ---------- Part 2: paying ----------

app.post('/api/bills/:billId/shares/:shareId/pay', async (c) => {
  const db = c.env.DB
  const key = parseIdempotencyKey(c.req.header('Idempotency-Key'))
  if (!key.ok) return c.json({ error: key.error }, 400)

  const billId = c.req.param('billId')
  const shareId = c.req.param('shareId')

  // A single UPDATE both checks "still unpaid" and marks it paid. SQLite runs one statement at a
  // time, so when two requests race only one UPDATE matches a row; the other gets no row back.
  const paidNow = await db
    .prepare(
      `UPDATE shares
       SET paid_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now'), idempotency_key = ?
       WHERE id = ? AND bill_id = ? AND paid_at IS NULL
       RETURNING id, member_id, amount_cents, paid_at`,
    )
    .bind(key.value, shareId, billId)
    .first<PaidShareRow>()
  if (paidNow) return c.json(toPaid(paidNow))

  // Not updated: the share does not exist, or it was already paid.
  const existing = await db
    .prepare(
      `SELECT id, member_id, amount_cents, paid_at, idempotency_key
       FROM shares WHERE id = ? AND bill_id = ?`,
    )
    .bind(shareId, billId)
    .first<PaidShareRow & { idempotency_key: string | null }>()
  if (!existing) return c.json({ error: 'Bill or share not found' }, 404)
  if (existing.idempotency_key === key.value) return c.json(toPaid(existing)) // repeat: same answer
  return c.json({ error: 'Share is already paid' }, 409)
})

function toPaid(row: PaidShareRow) {
  return {
    id: row.id,
    memberId: row.member_id,
    amountCents: row.amount_cents,
    paidAt: row.paid_at,
  }
}

// ---------- Part 2: balances ----------

app.get('/api/homes/:homeId/balances', async (c) => {
  const db = c.env.DB
  const homeId = c.req.param('homeId')
  if (!(await homeExists(db, homeId))) return c.json({ error: 'Home not found' }, 404)

  const { results } = await db
    .prepare(
      `SELECT m.id AS memberId, m.name AS name, COALESCE(SUM(s.amount_cents), 0) AS outstandingCents
       FROM members m
       LEFT JOIN shares s ON s.member_id = m.id AND s.paid_at IS NULL
       WHERE m.home_id = ?
       GROUP BY m.id ORDER BY m.seq`,
    )
    .bind(homeId)
    .all<{ memberId: string; name: string; outstandingCents: number }>()
  return c.json({ balances: results })
})

export default app
