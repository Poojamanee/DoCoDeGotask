import { createFileRoute, useNavigate } from '@tanstack/react-router'
import { type FormEvent, useState } from 'react'
import { api } from '../api'

export const Route = createFileRoute('/')({
  component: Start,
})

function Start() {
  const navigate = useNavigate()
  const [name, setName] = useState('')
  const [homeId, setHomeId] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function createHome(event: FormEvent) {
    event.preventDefault()
    if (busy) return
    setBusy(true)
    setError(null)
    try {
      const home = await api.createHome(name)
      await navigate({ to: '/homes/$homeId', params: { homeId: home.id } })
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Something went wrong.')
      setBusy(false)
    }
  }

  async function openHome(event: FormEvent) {
    event.preventDefault()
    const id = homeId.trim()
    if (id) await navigate({ to: '/homes/$homeId', params: { homeId: id } })
  }

  return (
    <main>
      <h1>Bill Splitter</h1>
      <p className="muted">Split shared bills between the people in your home.</p>

      <h2>Create a home</h2>
      <form className="row" onSubmit={createHome}>
        <label>
          Home name
          <input value={name} onChange={(e) => setName(e.target.value)} required maxLength={200} />
        </label>
        <button type="submit" disabled={busy}>
          {busy ? 'Creating…' : 'Create home'}
        </button>
      </form>
      {error && (
        <p role="alert" className="error">
          {error}
        </p>
      )}

      <h2>Open an existing home</h2>
      <form className="row" onSubmit={openHome}>
        <label>
          Home id
          <input value={homeId} onChange={(e) => setHomeId(e.target.value)} required />
        </label>
        <button type="submit">Open</button>
      </form>
    </main>
  )
}
