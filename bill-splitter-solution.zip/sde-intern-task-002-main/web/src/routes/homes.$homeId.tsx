import { createFileRoute, Link } from '@tanstack/react-router'
import { type FormEvent, useCallback, useEffect, useRef, useState } from 'react'
import { api, type Bill, dollarsToCents, formatCents, type HomeDetails, type Share } from '../api'

export const Route = createFileRoute('/homes/$homeId')({
  component: HomePage,
})

type Loaded = { home: HomeDetails; bills: Bill[] }
type Load =
  | { state: 'loading' }
  | { state: 'error'; message: string }
  | ({ state: 'ready' } & Loaded)

function message(error: unknown): string {
  return error instanceof Error ? error.message : 'Something went wrong.'
}

function HomePage() {
  const { homeId } = Route.useParams()
  const [load, setLoad] = useState<Load>({ state: 'loading' })

  const refresh = useCallback(
    async (signal?: AbortSignal) => {
      try {
        const [home, bills] = await Promise.all([
          api.getHome(homeId, signal),
          api.getBills(homeId, signal),
        ])
        setLoad({ state: 'ready', home, bills: bills.bills })
      } catch (error) {
        if (signal?.aborted) return
        setLoad({ state: 'error', message: message(error) })
      }
    },
    [homeId],
  )

  useEffect(() => {
    setLoad({ state: 'loading' })
    const controller = new AbortController()
    void refresh(controller.signal)
    return () => controller.abort()
  }, [refresh])

  return (
    <main>
      <p>
        <Link to="/">← All homes</Link>
      </p>
      {load.state === 'loading' && (
        <p className="state" role="status">
          Loading…
        </p>
      )}
      {load.state === 'error' && (
        <div className="state" role="alert">
          <p className="error">{load.message}</p>
          <button
            type="button"
            onClick={() => {
              setLoad({ state: 'loading' })
              void refresh()
            }}
          >
            Try again
          </button>
        </div>
      )}
      {load.state === 'ready' && (
        <Ready homeId={homeId} home={load.home} bills={load.bills} onChanged={() => refresh()} />
      )}
    </main>
  )
}

function Ready(props: {
  homeId: string
  home: HomeDetails
  bills: Bill[]
  onChanged: () => Promise<void>
}) {
  const { homeId, home, bills, onChanged } = props
  return (
    <>
      <h1>{home.name}</h1>
      <p className="muted">
        {home.members.length === 0
          ? 'No members yet.'
          : `Members: ${home.members.map((m) => m.name).join(', ')}`}
      </p>
      <AddMember homeId={homeId} onAdded={onChanged} />

      <h2>Bills</h2>
      <AddBill homeId={homeId} canSplit={home.members.length > 0} onAdded={onChanged} />
      {bills.length === 0 ? (
        <p className="state">No bills yet. Add one above.</p>
      ) : (
        bills.map((bill) => <BillCard key={bill.id} bill={bill} onPaid={onChanged} />)
      )}
    </>
  )
}

/** A small form: validates nothing itself, shows whatever the API or the network says. */
function useSubmit(action: () => Promise<void>) {
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const submit = async (event: FormEvent) => {
    event.preventDefault()
    if (busy) return
    setBusy(true)
    setError(null)
    try {
      await action()
    } catch (e) {
      setError(message(e))
    } finally {
      setBusy(false)
    }
  }
  return { busy, error, submit }
}

function AddMember({ homeId, onAdded }: { homeId: string; onAdded: () => Promise<void> }) {
  const [name, setName] = useState('')
  const { busy, error, submit } = useSubmit(async () => {
    await api.addMember(homeId, name)
    setName('')
    await onAdded()
  })
  return (
    <>
      <form className="row" onSubmit={submit}>
        <label>
          New member
          <input value={name} onChange={(e) => setName(e.target.value)} required maxLength={200} />
        </label>
        <button type="submit" disabled={busy}>
          {busy ? 'Adding…' : 'Add member'}
        </button>
      </form>
      {error && (
        <p role="alert" className="error">
          {error}
        </p>
      )}
    </>
  )
}

function AddBill(props: { homeId: string; canSplit: boolean; onAdded: () => Promise<void> }) {
  const { homeId, canSplit, onAdded } = props
  const [title, setTitle] = useState('')
  const [amount, setAmount] = useState('')
  const { busy, error, submit } = useSubmit(async () => {
    const cents = dollarsToCents(amount)
    if (cents === null) throw new Error('Enter an amount above zero, like 12.50.')
    await api.addBill(homeId, title, cents)
    setTitle('')
    setAmount('')
    await onAdded()
  })
  return (
    <>
      <form className="row" onSubmit={submit}>
        <label>
          Title
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
            maxLength={200}
          />
        </label>
        <label>
          Amount ($)
          <input
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            inputMode="decimal"
            placeholder="12.50"
            required
          />
        </label>
        <button type="submit" disabled={busy || !canSplit}>
          {busy ? 'Adding…' : 'Add bill'}
        </button>
      </form>
      {!canSplit && <p className="muted">Add at least one member before adding a bill.</p>}
      {error && (
        <p role="alert" className="error">
          {error}
        </p>
      )}
    </>
  )
}

function BillCard({ bill, onPaid }: { bill: Bill; onPaid: () => Promise<void> }) {
  return (
    <section className="card">
      <header>
        <span>{bill.title}</span>
        <span>{formatCents(bill.totalCents)}</span>
      </header>
      <ul className="shares">
        {bill.shares.map((share) => (
          <ShareRow key={share.id} billId={bill.id} share={share} onPaid={onPaid} />
        ))}
      </ul>
    </section>
  )
}

function ShareRow(props: { billId: string; share: Share; onPaid: () => Promise<void> }) {
  const { billId, share, onPaid } = props
  const [paying, setPaying] = useState(false)
  const [error, setError] = useState<string | null>(null)
  // One key per share, kept between clicks. If a request times out we do not know whether it
  // went through; clicking again with the same key is safe, the server will not pay twice.
  const key = useRef<string | null>(null)

  async function pay() {
    if (paying) return
    setPaying(true)
    setError(null)
    key.current ??= crypto.randomUUID()
    try {
      await api.payShare(billId, share.id, key.current)
      key.current = null
      await onPaid()
    } catch (e) {
      // The share stays unpaid on screen: we only change it after the server confirms.
      setError(message(e))
    } finally {
      setPaying(false)
    }
  }

  return (
    <li>
      <span className="who">{share.memberName}</span>
      <span>{formatCents(share.amountCents)}</span>
      {share.paidAt ? (
        <span className="paid">Paid</span>
      ) : (
        <button type="button" onClick={pay} disabled={paying}>
          {paying ? 'Paying…' : 'Pay'}
        </button>
      )}
      {error && (
        <span role="alert" className="error">
          {error}
        </span>
      )}
    </li>
  )
}
