export type Member = { id: string; homeId: string; name: string }
export type Share = {
  id: string
  memberId: string
  memberName: string
  amountCents: number
  paidAt: string | null
}
export type Bill = {
  id: string
  homeId: string
  title: string
  totalCents: number
  shares: Share[]
}
export type HomeDetails = { id: string; name: string; members: Member[] }
export type PaidShare = { id: string; memberId: string; amountCents: number; paidAt: string }

export class ApiError extends Error {}

const TIMEOUT_MS = 15_000

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null
}

/**
 * One place for every request. It never throws anything but ApiError, so callers only
 * have one kind of failure to show: a server error, a bad body, a timeout, or no network.
 */
async function request<T>(
  method: 'GET' | 'POST',
  path: string,
  options: { body?: unknown; headers?: Record<string, string>; signal?: AbortSignal } = {},
): Promise<T> {
  const timeout = AbortSignal.timeout(TIMEOUT_MS)
  const signal = options.signal ? AbortSignal.any([options.signal, timeout]) : timeout
  let response: Response
  try {
    response = await fetch(path, {
      method,
      signal,
      headers: { 'content-type': 'application/json', ...options.headers },
      body: options.body === undefined ? undefined : JSON.stringify(options.body),
    })
  } catch (error) {
    if (options.signal?.aborted) throw error // the caller cancelled; not a failure to show
    if (timeout.aborted) throw new ApiError('The server took too long to answer. Try again.')
    throw new ApiError('Could not reach the server. Check your connection and try again.')
  }

  let data: unknown
  try {
    data = await response.json()
  } catch {
    data = undefined
  }
  if (!response.ok) {
    const message = isRecord(data) && typeof data.error === 'string' ? data.error : null
    throw new ApiError(message ?? `Something went wrong (error ${response.status}).`)
  }
  if (data === undefined) throw new ApiError('The server sent an answer we could not read.')
  return data as T
}

export const api = {
  createHome: (name: string) =>
    request<{ id: string; name: string }>('POST', '/api/homes', { body: { name } }),
  getHome: (homeId: string, signal?: AbortSignal) =>
    request<HomeDetails>('GET', `/api/homes/${encodeURIComponent(homeId)}`, { signal }),
  addMember: (homeId: string, name: string) =>
    request<Member>('POST', `/api/homes/${encodeURIComponent(homeId)}/members`, { body: { name } }),
  getBills: (homeId: string, signal?: AbortSignal) =>
    request<{ bills: Bill[] }>('GET', `/api/homes/${encodeURIComponent(homeId)}/bills`, { signal }),
  addBill: (homeId: string, title: string, totalCents: number) =>
    request<Bill>('POST', `/api/homes/${encodeURIComponent(homeId)}/bills`, {
      body: { title, totalCents },
    }),
  payShare: (billId: string, shareId: string, idempotencyKey: string) =>
    request<PaidShare>(
      'POST',
      `/api/bills/${encodeURIComponent(billId)}/shares/${encodeURIComponent(shareId)}/pay`,
      { headers: { 'Idempotency-Key': idempotencyKey } },
    ),
}

/** "12.5" -> 1250. Parses the text itself, so no floating point ever touches money. */
export function dollarsToCents(input: string): number | null {
  const match = /^(\d{1,12})(?:\.(\d{1,2}))?$/.exec(input.trim())
  if (!match) return null
  const cents = Number(match[1]) * 100 + Number((match[2] ?? '').padEnd(2, '0'))
  return cents > 0 ? cents : null
}

const money = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' })
export function formatCents(cents: number): string {
  return money.format(cents / 100)
}
